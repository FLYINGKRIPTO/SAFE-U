package com.womensafety.shajt3ch;



public class Model {
    public String name_of_choice;

    public Model(String name_of_choice) {
        this.name_of_choice = name_of_choice;
    }
}
