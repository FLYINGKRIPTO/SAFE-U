# Women_Safety_Box
This is an Android App for Women or any Female, which Will Call to an Emergency number, based on a specific voice command like "Help" . It will also send SMS with current GPS coordinates to those numbers.

*Make Sure that "Google" App is Installed on your phone and you give this App proper Access Permission like Call, SMS, Microphone.

1. Registration - 

![1 reg](https://user-images.githubusercontent.com/15268903/44601093-3d313680-a7fd-11e8-9e94-ba3b77d0dfc3.gif)

2. Background Voice recognation service and Help mode execution with Auto call and SMS - 

![2 help](https://user-images.githubusercontent.com/15268903/44601241-ab75f900-a7fd-11e8-92a9-28bbce9630ca.gif)

3. Nearby Police Station and Hospital location - 


![3 nearbynew](https://user-images.githubusercontent.com/15268903/44601629-e9bfe800-a7fe-11e8-80f5-bbe24faf4e4f.gif)

4. Information Module containing Fast Aid and Self Defence Info - 

![4 safetytips](https://user-images.githubusercontent.com/15268903/44601775-65219980-a7ff-11e8-93c2-547ecff322ee.gif)




